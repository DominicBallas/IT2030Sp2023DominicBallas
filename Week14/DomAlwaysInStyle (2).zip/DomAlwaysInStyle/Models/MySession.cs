﻿using Microsoft.AspNetCore.Mvc;

namespace DomAlwaysInStyle.models
{
    public class MySession : Controller
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Course { get; set; }
        public int FavNum { get; set; }
    }
}


