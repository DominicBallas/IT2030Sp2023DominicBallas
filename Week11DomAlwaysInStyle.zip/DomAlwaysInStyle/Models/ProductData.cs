﻿namespace DomAlwaysInStyle.Models
{
    public class ProductData
    {
        public static List<ProductModel> GetProducts()
        {
            List<ProductModel> products = new List<ProductModel>
            {
                new ProductModel
                {
                    ProductID = 1,
                    ProductName = "Short Sleeve T-Shirt",
                    ProductDescription = "Comfortable Affordable Cotton Graphic Tee",
                    ProductImage = "SSTshirt.jpg",
                    ProductPrice = 12
                },

                new ProductModel
                {
                    ProductID = 2,
                    ProductName = "Long Sleeve T-Shirt",
                    ProductDescription = "Comfortable Affordable Cotton Long Sleeve",
                    ProductImage = "LSTshirt.jpg",
                    ProductPrice = 15
                },

                new ProductModel
                {
                    ProductID = 3,
                    ProductName = "Gym Shorts",
                    ProductDescription = "Breathable Light Short Engineered For Active Folk",
                    ProductImage = "GymShorts.jpg",
                    ProductPrice = 16
                },

                new ProductModel
                {
                    ProductID = 4,
                    ProductName = "Jogger Sweatpants",
                    ProductDescription = "Jogger Cuffed Sweatpants For Everyday",
                    ProductImage = "Joggers.jpg",
                    ProductPrice = 19
                },

                new ProductModel
                {
                    ProductID = 5,
                    ProductName = " Hooded Sweatshirt",
                    ProductDescription = "Feeling Lazy?! Throw On Our Comfortable Sweatshirt!",
                    ProductImage = "Sweatshirt.jpg",
                    ProductPrice = 23
                },

                new ProductModel
                {
                    ProductID = 6,
                    ProductName = "Socks (available in mens and womens) ",
                    ProductDescription = "Affordble Sock Kit for everyday use",
                    ProductImage = "Socks.jpg",
                    ProductPrice = 10
                },
            };
            return products;
        }

        public static ProductModel GetProduct(int id)
        {
            List<ProductModel> products = ProductData.GetProducts();
            foreach (ProductModel product in products)
            {
                if (product .ProductID == id)
                {
                    return product;
                }
            }
            return new ProductModel();
        }
    }
}
            
