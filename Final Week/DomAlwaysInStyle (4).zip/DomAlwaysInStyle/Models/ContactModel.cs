﻿using System.ComponentModel.DataAnnotations;

namespace DomAlwaysInStyle.Models
{
    public class ContactModel
    {

        [Key]
        public int ContactId { get; set; }

        [Required(ErrorMessage = "Please enter a first name")]
        [StringLength(30, ErrorMessage = "Name must be 30 characters or less")]
        [RegularExpression("^[a-zA-Z''-'/s]{1,30}$", ErrorMessage = "Name may not contain special characters")]
        public string? firstName { get; set; }

        [Required(ErrorMessage = "Please enter a last name")]
        [StringLength(30, ErrorMessage = "Name must be 30 characters or less")]
        [RegularExpression("^[a-zA-Z''-'/s]{1,30}$", ErrorMessage = "Name may not contain special characters")]
        public string? lastName { get; set; }

        [Required(ErrorMessage = "Please enter an address")]
        public string? address { get; set; }

        [Required(ErrorMessage = "Please enter a phone number")]
        [RegularExpression("^[0-9]{10}$", ErrorMessage = "Phone number must contain 10 digits and numbers only")]
        public decimal? phone { get; set; }

        [Required(ErrorMessage = "Please enter an email")]
        [EmailAddress(ErrorMessage = "Email address is invalid")]
        public string? email { get; set; }

        [Required(ErrorMessage = "Please enter a message")]
        public string? message { get; set; }

    }
}


