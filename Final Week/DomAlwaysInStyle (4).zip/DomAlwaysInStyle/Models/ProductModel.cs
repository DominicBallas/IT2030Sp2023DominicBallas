﻿using System.ComponentModel.DataAnnotations;

namespace DomAlwaysInStyle.Models
{
    
     public class ProductModel
    {
        [Key]
        public int productId { get; set; }

        [Required(ErrorMessage = "Required name of product")]
        public string productName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Description of product is required")]
        public string productDescription { get; set; } = string.Empty;

        [Required(ErrorMessage = "Image is required")]
        public string productImage { get; set; } = string.Empty;

        [DataType(DataType.Currency)]
        public decimal productPrice { get; set; }

    }
}


