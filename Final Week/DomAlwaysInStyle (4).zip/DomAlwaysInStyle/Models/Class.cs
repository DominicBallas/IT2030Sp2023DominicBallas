﻿namespace DomAlwaysInStyle.Models
{
    public class ContactModel
    {
    }
}
