﻿namespace DomAlwaysInStyle.Models
{
    public class ProductData
    {
        public static List<ProductModel> GetProducts()
        {
            List<ProductModel> products = new List<ProductModel>
            {
                new ProductModel
                {
                    productId = 1,
                    productName = "Short Sleeve T-Shirt",
                    productDescription = "Comfortable Affordable Cotton Graphic Tee",
                    productImage = "SSTshirt.jpg",
                    productPrice = 12
                },

                new ProductModel
                {
                    productId = 2,
                    productName = "Long Sleeve T-Shirt",
                    productDescription = "Comfortable Affordable Cotton Long Sleeve",
                    productImage = "LSTshirt.jpg",
                    productPrice = 15
                },

                new ProductModel
                {
                    productId= 3,
                    productName = "Gym Shorts",
                    productDescription = "Breathable Light Short Engineered For Active Folk",
                    productImage = "GymShorts.jpg",
                    productPrice = 16
                },

                new ProductModel
                {
                    productId = 4,
                    productName = "Jogger Sweatpants",
                    productDescription = "Jogger Cuffed Sweatpants For Everyday",
                    productImage = "Joggers.jpg",
                    productPrice = 19
                },

                new ProductModel
                {
                    productId = 5,
                    productName = " Hooded Sweatshirt",
                    productDescription = "Feeling Lazy?! Throw On Our Comfortable Sweatshirt!",
                    productImage = "Sweatshirt.jpg",
                    productPrice = 23
                },

                new ProductModel
                {
                    productId = 6,
                    productName = "Socks (available in mens and womens) ",
                   productDescription = "Affordble Sock Kit for everyday use",
                    productImage = "Socks.jpg",
                   productPrice = 10
                },
            };
            return products;
        }

        public static ProductModel GetProduct(int id)
        {
            List<ProductModel> products = ProductData.GetProducts();
            foreach (ProductModel product in products)
            {
                if (product .productId == id)
                {
                    return product;
                }
            }
            return new ProductModel();
        }
    }
}
            
