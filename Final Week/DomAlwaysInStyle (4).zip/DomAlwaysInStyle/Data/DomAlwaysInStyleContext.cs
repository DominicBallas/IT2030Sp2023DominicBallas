﻿using DomAlwaysInStyle.Models;
using Microsoft.EntityFrameworkCore;
using static DomAlwaysInStyle.Data.DomAlwaysInStyleContext;

namespace DomAlwaysInStyle.Data
{
   
        public class DomAlwaysInStyleContext : DbContext
        {
            public DomAlwaysInStyleContext(DbContextOptions<DomAlwaysInStyleContext> options)
                : base(options)
            {
            }


            public DbSet<ContactModel> ContactDb { get; set; }
            public DbSet<ProductModel> ProductDb { get; set; }
        }
    }
